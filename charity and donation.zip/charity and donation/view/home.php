<?php 
    require_once '../controller/sessionCheck.php';
?>

<html lang="en">
<head>
    <title>Home</title>
</head>
<body>
    <h1>Welcome Home! </h1> 
    <a href="educationalResources.php">Educational resources</a>  <br> 
    <a href="reportingAndAnalytics.php">Report and Analytics</a><br>
    <a href="currencyConverter.php">Currency Converter</a><br>
    <a href="logout.php">logout </a>
</body>
</html>