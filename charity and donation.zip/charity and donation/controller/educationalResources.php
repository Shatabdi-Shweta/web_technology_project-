<?php
    include_once '../model/educationalResource.php';

    function all_resources() {
        $resource = all_resource();

        return $resource;
    }
?>